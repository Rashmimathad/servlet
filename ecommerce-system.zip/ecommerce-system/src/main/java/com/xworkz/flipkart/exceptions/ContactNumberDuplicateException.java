package com.xworkz.flipkart.exceptions;

public class ContactNumberDuplicateException extends RuntimeException{
    public ContactNumberDuplicateException(String message) {
        super(message);
    }
}
