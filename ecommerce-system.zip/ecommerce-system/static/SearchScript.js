function showSearchDetails(){
 document.getElementById("searchDetails").style.display="block";
}